import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeService {

    List<Employee> list = EmployeeRepos.getEmployees();

    public Employee getEmployee(int id, String name) {
        for (Employee e : list) {
            if (e.getId() == id && e.getName() == name) {
                return e;
            }
        }
        return null;
    }

    public List<Employee> getEmployees(Double salary) {
        List<Employee> result = new ArrayList<>();
        for (Employee e : list) {
            if (e.getSalary() > salary) {
                result.add(e);
            }
        }
        return result;
    }

    public Double getMaxSalary() {
        Double max = 0.00;
        for (Employee e : list) {
            if (e.getSalary() > max) {
                max = e.getSalary();
            }
        }

        return max;
    }

    public Double getSumOfSalary() {
        Double sum = 0.00;
        for (Employee e : list) {
            sum += e.getSalary();
        }
        return sum;
    }

    public List<String> getNames(String city) {
        List<String> result = new ArrayList<>();
        for (Employee e : list) {
            if (e.getLocation().equals(city)) {
                result.add(e.getName());
            }
        }
        return result;
    }

    public List<Employee> getDetails() {

        List<Employee> employeesSortedList = list.stream()
                .sorted((o1, o2) -> (int) (o1.getSalary() - o2.getSalary())).collect(Collectors.toList());

        return employeesSortedList;
    }

    public List<Employee> getManagers() {
        List<Employee> result = new ArrayList<>();
        for (Employee e : list) {
            if (e.getDesignation().equals("Manager")) {
                result.add(e);
            }
        }
        return result;
    }

    public Double getSumOfManagerSalaries() {
        Double sum = 0.00;
        for (Employee e : list) {
            if (e.getDesignation().equals("Manager")) {
                sum += e.getSalary();
            }
        }
        return sum;
    }

    public List<String> getIds() {
        List<String> res = new ArrayList<>();
        for (Employee e : list) {
            String id = String.valueOf(e.getId());
            res.add(id);
        }
        return res;
    }
}
